package validateschema;

import java.io.File;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Cookies {
	
	public static String cookie;
	
	@BeforeMethod
	public void extractCookie() {
		
	RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
		//Authentication
	RestAssured.authentication=RestAssured.basic("admin", "I-Ks*dzGjO63");

		Response response = RestAssured.given()
		.queryParam("sysparm_fields", "short_description,description,sys_id,number")
		.get("incident");
		
		 cookie = response.getCookie("JSESSIONID");
		
		 System.out.println("Cookie is -----------"+cookie);
		
	}
	
	@Test
	public void create() {
		
		//End point Url
		RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
		//Authentication
		//RestAssured.authentication=RestAssured.basic("admin", "I-Ks*dzGjO63");
		
		//Form the  Request body
		RequestSpecification input = RestAssured.given()
	      .contentType("application/json")
	      .cookie("JSESSIONID",cookie)
	    //  .cookie("JSESSIONID","090344856BEB09C6EF76DD2DA568A474")
	     //.queryParam("sysparm_fields", "short_description,sys_id,number")
	      .when()
	      .body("{\r\n"
	      		+ "    \"short_description\": \"laptop\",\r\n"
	      		+ "    \"description\": \"sevice my laptop\"\r\n"
	      		+ "}");
	      
		 //Send Request
		  Response response = input.post("incident");
		 
         response.prettyPrint();
		
		
		 
		 
		 
		 
		 
		 
		 
		 
		
		
	}

}
