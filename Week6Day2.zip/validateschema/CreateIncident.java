package validateschema;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident {
	
	
	@Test
	public void create() {
		
		//End point Url
		RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
		//Authentication
		RestAssured.authentication=RestAssured.basic("admin", "I-Ks*dzGjO63");
		
		//Form the  Request body
		
	       RequestSpecification input = RestAssured.given()
	      .contentType("application/json")
	     //.queryParam("sysparm_fields", "short_description,sys_id,number")
	      .when()
	      .body("{\r\n"
	      		+ "    \"short_description\": \"laptop\",\r\n"
	      		+ "    \"description\": \"sevice my laptop\"\r\n"
	      		+ "}");
	      
		 //Send Request
		  Response response = input.post("incident");
		 
	  // Validate schema
		  
		  File schema=new File("./src/test/resources/Schema.json");
response.then().assertThat()
.body(JsonSchemaValidator.matchesJsonSchema(schema));
		
		
		 
		 
		 
		 
		 
		 
		 
		 
		
		
	}

}
