package assertions;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident extends BaseclassAssert {
	
	
	@Test
	public void create() {
		
		//End point Url
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table/";
		
		//Authentication
		RestAssured.authentication=RestAssured.basic("admin", "NQvluT54==pQ");
		
		//Form the  Request body
		
	      RequestSpecification input = RestAssured.given()
	      .contentType("application/json")
	      .accept("application/json")
	      .when()
	      .body("{\r\n"
	      		+ "    \"short_description\": \"laptop\",\r\n"
	      		+ "    \"description\": \"sevice my laptop\"\r\n"
	      		+ "}");
	      
		 //Send Request
		  Response response = input.post("incident");
		 
		  String statusLine = response.getStatusLine();
		  System.out.println(statusLine);
		 //Print Response
		 response.prettyPrint();
        sys_id=response.jsonPath().get("result.sys_id");
		 System.out.println("sys_id in create"+sys_id);
		 //Validate Response
		 response.then().assertThat().statusCode(Matchers.equalTo(201));
		 response.then().assertThat().body("result.number",Matchers.containsString("INC"));
		 
		 response.then().assertThat().statusLine(Matchers.containsString("201"));
		 
		 
		 
		 
		 
		 
		 
		 
		
		
	}

}
