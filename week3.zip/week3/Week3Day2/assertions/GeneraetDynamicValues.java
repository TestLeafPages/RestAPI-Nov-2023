package assertions;

import org.testng.annotations.Test;

import com.github.javafaker.Faker;

public class GeneraetDynamicValues {

	@Test
	public void dynamicValues() {
		
		Faker fake=new Faker();
		String fullName = fake.name().fullName();
		String firstName = fake.name().firstName();
		String email=fake.internet().emailAddress();
	    String emailID=firstName+"@"+"testleaf.com";
		System.out.println(fullName+"-"+firstName+"-"+email+emailID);
		
		
		
	}
}
