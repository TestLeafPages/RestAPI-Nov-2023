package assertions;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetIncidentsWithQP extends  BaseclassAssert {


	@Test(dependsOnMethods = "assertions.CreateIncident.create")
	public void getIncidents() {

		//End point Url
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table/";

		//Authentication
		RestAssured.authentication=RestAssured.basic("admin", "NQvluT54==pQ");

		Response response = RestAssured.given()
		.queryParam("sysparm_fields", "short_description,description,sys_id,number")
		.get("incident");
		System.out.println("sys id in get requqest"+sys_id);
	    response.then().assertThat().body("result.sys_id", Matchers.hasItem(sys_id));
	    response.then().assertThat().body("result.number", Matchers.hasItem("INC0013250"));
	   
	  
		
	}
}
