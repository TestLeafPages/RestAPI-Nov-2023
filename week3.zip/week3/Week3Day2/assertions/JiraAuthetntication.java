package assertions;

import io.restassured.RestAssured;

public class JiraAuthetntication {
	
	
	public void create() {
		
		RestAssured.authentication=RestAssured.preemptive().basic("username", "Jira key");
	}

}
