package chaining;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateIncident extends Baseclass {



	@Test(dependsOnMethods ="chaining.CreateIncident.create")   //Packagename.Classname.MethodName
	public void update() {
	//Form the Request
			RequestSpecification input = RestAssured.given()
		.contentType("application/json")
		.when()
		.body("{\r\n"
				+ "    \"short_description\": \"Desktop\",\r\n"
				+ "    \"description\": \"sevice my desktop\"\r\n"
				+ "}");
		
		//Send Request
		Response response = input.put("incident/"+sys_id);
		
		String asPrettyString = response.asPrettyString();
		
		 
		 
		 System.out.println("The response code for update request----"+response.getStatusCode());
		 response.then().assertThat().statusCode(Matchers.equalTo(200));
		 
		 
		 
		 
		 
		 
		 
		 
		 
		
		
		
		
		
	}

}
