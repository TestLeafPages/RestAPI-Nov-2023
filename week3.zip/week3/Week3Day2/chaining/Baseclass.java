package chaining;

import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;

public class Baseclass {

	public static String sys_id;
	
	@BeforeMethod
	public void base() {
		
		//End point Url
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table/";
		
		//Authentication
		RestAssured.authentication=RestAssured.basic("admin", "NQvluT54==pQ");
	}
}
