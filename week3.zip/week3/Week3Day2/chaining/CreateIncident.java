package chaining;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident extends Baseclass {

	@Test
	public void create() {
		
		//Form the  Request body
		
	      RequestSpecification input = RestAssured.given()
	      .contentType("application/json")
	      .when()
	      .body("{\r\n"
	      		+ "    \"short_description\": \"laptop\",\r\n"
	      		+ "    \"description\": \"sevice my laptop\"\r\n"
	      		+ "}");
	      
		 //Send Request
		  Response response = input.post("incident");
		  response.prettyPrint();
		  
		  //Extract Sys_id
		   sys_id = response.jsonPath().get("result.sys_id");
		  
		  //Assert status code
		   response.then().assertThat().statusCode(Matchers.equalTo(201));
		  
		  
		  
		  
	}
}
