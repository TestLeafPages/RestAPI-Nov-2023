package chaining;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteAllIncidentsUsingGetMethod {

	@Test
	public void getIncident() {

		//End point Url
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table/";

		//Authentication
		RestAssured.authentication=RestAssured.basic("admin", "NQvluT54==pQ");
		
		/*Response response = RestAssured.given()
		.queryParam("sysparm_fields","short_description,description,sys_id,number")
		.queryParam("sysparm_limit", "3")
		.get("incident");*/
		
		Map<String,String> queryParameters=new HashMap<String,String>();
		queryParameters.put("sysparm_fields", "short_description,description,sys_id,number");
		queryParameters.put("sysparm_limit", "3");
		
		Response response = RestAssured.given()
		.queryParams(queryParameters)
		.get("incident");
		
		List<String> sys_ids = response.jsonPath().getList("result.sys_id");
		System.out.println("Size of the list---"+sys_ids.size());
		for (String it_sysid : sys_ids) {
			
			Response response1 = RestAssured.delete("incident/"+it_sysid);
			response1.then().assertThat().statusCode(Matchers.equalTo(204));
		
			
		}
		response.prettyPrint();
	}
}
