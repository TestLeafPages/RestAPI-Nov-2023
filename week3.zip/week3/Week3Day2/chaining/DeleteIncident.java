package chaining;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteIncident extends Baseclass{

	@Test(dependsOnMethods ="chaining.UpdateIncident.update",invocationCount = 2)
	public void delete() {
		
		
		//Send Request
		Response response = RestAssured.delete("incident/"+sys_id);
		
		System.out.println("Delete Status Code----"+response.getStatusCode());
		
		 response.then().assertThat().statusCode(Matchers.equalTo(204));
	}
}
